<?php

/**
 * Fired when the plugin is uninstalled via WordPress Admin.
 *
 * @package BotPlus
 */

// If uninstall not called from WordPress, exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

$autoload = plugin_dir_path(__FILE__) . 'vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
} else {
    // Native PSR-4 fallback autoloader for standalone distribution package
    spl_autoload_register(function ($class) {
        $prefix = 'BotPlus\\Plugin\\';
        $baseDir = plugin_dir_path(__FILE__) . 'includes/';
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            return;
        }
        $relativeClass = substr($class, $len);
        $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    });
}

$helpers = plugin_dir_path(__FILE__) . 'includes/Utilities/Helpers.php';
if (file_exists($helpers)) {
    require_once $helpers;
}

\BotPlus\Plugin\Core\Installer::uninstall();

